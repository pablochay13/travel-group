<h1>Registro de formulario registro Cancun Travel Experience</h1>

<p>Nombre: {{ $data['name'] }}</p>
<p>Email: {{ $data['email'] }}</p>
<p>Teléfono: {{ $data['tel'] }}</p>
<p>Fechas: {{ $data['date'] }}</p>
<p>Mensaje: {{ $data['message'] }}.</p>
