<?php

return [
    'nav' => [
        0 => 'Inicio',
        1 => 'Opiniones',
        2 => 'Acerca de nosotros',
        3 => 'Contacto',
        4 => 'Todas las experiencias',
        5 => 'Traslados',
    ],
];
